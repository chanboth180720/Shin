package Ex9;

public class Student {
    private int number;
    private String Fname, Lname;

    @Override
    public String toString() {
        return "Contact{" +
                "number=0" + number +
                ", Fname='" + Fname + '\'' +
                ", Lname='" + Lname + '\'' +
                '}';
    }

    public Student() {
    }

    public Student(int number) {
        this.number = number;
    }

    public Student(String fname, String lname) {
        Fname = fname;
        Lname = lname;
    }

    public Student(int number, String fname, String lname) {
        this.number = number;
        Fname = fname;
        Lname = lname;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }
}
