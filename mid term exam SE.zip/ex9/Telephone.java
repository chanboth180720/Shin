package Ex9;

import java.util.Scanner;

public class Telephone {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Studentlist list = new Studentlist();
        while (true){
            list.Menu();
            int i = sc.nextInt();

            if (i == 1){
                list.addNewContact();
            }else if (i == 2) {
                list.ListingContact();
            }else if (i == 3){
                System.out.printf("Please input number to update: ");
                String number = sc.nextLine();
                list.updateByNumber(number);
            }
            else if (i == 4){
                System.out.printf("Please input last name to remove: ");
                String Lname = sc.nextLine();
                list.removeByName(Lname);
            }
            else if (i == 5){
                break;
            }else {
                System.out.println("Wrong number!!!");
            }

        }
    }
}
