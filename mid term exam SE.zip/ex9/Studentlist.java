package Ex9;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Studentlist {
    private ArrayList<Student> list = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    public void addNewContact(){
        Student contact = new Student();
        System.out.printf("Please input new contact number: ");
        contact.setNumber(Integer.parseInt(sc.nextLine()));
        System.out.printf("Input new contact Fist name: ");
        contact.setFname(sc.nextLine());
        System.out.printf("Input new contact Last name: ");
        contact.setLname(sc.nextLine());
        list.add(contact);
    }

    public void ListingContact(){
        for (Student contact: list){
            System.out.println(contact.toString());
        }
    }

    public void updateByNumber(String number){
        Iterator<Student> itr = list.iterator();
        while (itr.hasNext()){
            Student contact = itr.next();
            if (number.equals(contact.getNumber())){
                System.out.println("Number: " + contact.getNumber() + "Name: " + contact.getFname() + " " + contact.getLname());
                System.out.printf("Please input new contact number: ");
                contact.setNumber(Integer.parseInt(sc.nextLine()));
                System.out.printf("Input new contact Fist name: ");
                contact.setFname(sc.nextLine());
                System.out.printf("Input new contact Last name: ");
                contact.setLname(sc.nextLine());
            }
            else {
                System.out.println("There are no " + number + "in the list!");
            }
        }
    }

    public void removeByName(String Lname){
        Iterator<Student> itr = list.iterator();
        while (itr.hasNext()){
            Student contact = itr.next();
            if (Lname.equals(contact.getLname())){
                System.out.println("Number: " + contact.getNumber() + "Name: " + contact.getFname() + " " + contact.getLname());
                itr.remove();

            }
            else {
                System.out.println("There are no " + Lname + "in the list!");
            }
        }
    }

    public void Menu(){
        System.out.printf("\t\tMenu\n" +
                "1. Add new contact\n" +
                "2. List all contacts\n" +
                "3. Update contacts\n" +
                "4. Remove contacts\n" +
                "5. Exit system\n" +
                "Please input number of options: ");
    }

}
